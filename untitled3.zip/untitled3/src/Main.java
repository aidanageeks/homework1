public class Main {
    public class StringExample1 {
        public static void main(String[] args) {
            int Hello;
            int world;
            Hello = 8;
            world = 7;
            String str1 = "Hello";
            System.out.println("world " + str1);
            System.out.println("First line\n" + "Second line");
            if (Hello <= 0)
                System.out.println("you saved negative number");
            if (Hello >= 0)
                System.out.println("you saved positive number");
            else {
                System.out.println("you saved zero");

            }
            class Program {

                public static void main(String[] args) {

                    System.out.println("Hello world!");
                    System.out.println("Bye world...");
                }

            }
        }
    }
}